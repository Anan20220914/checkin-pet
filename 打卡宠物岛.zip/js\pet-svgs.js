// pet-svgs.js — 蛋仔派对风程序化 SVG 宠物（14 只）
// 胖墩圆滚滚球体身体 + 超大眼 + 极简色块 + 标志性特征
// viewBox 0 200，描边 #3a2a1a，线宽 3.5，主色由 ${color} 传入

const STROKE = '#3a2a1a';
const SW = 3.5;

/** SVG 外壳 */
function svg(inner) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200" width="200" height="200">${inner}</svg>`;
}

/** 圆滚滚胖球身体（头身一体，几乎无脖子） */
function body(color, cx = 100, cy = 110, r = 60) {
  return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${color}" stroke="${STROKE}" stroke-width="${SW}"/>`;
}

/** 超大眼：白眼底 r16 + 黑瞳 r11 + 大高光 r5 + 小高光 r2.5 */
function eye(cx, cy) {
  return `<circle cx="${cx}" cy="${cy}" r="16" fill="#ffffff" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="${cx}" cy="${cy + 2}" r="11" fill="#2a2a2a"/>
<circle cx="${cx - 4}" cy="${cy - 4}" r="5" fill="#ffffff"/>
<circle cx="${cx + 5}" cy="${cy + 4}" r="2.5" fill="#ffffff"/>`;
}

/** 腮红 */
function cheek(cx, cy, r = 9) {
  return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#ff9bb0" opacity="0.55"/>`;
}

/** 小笑嘴 */
function smile(cx, cy, w = 12) {
  return `<path d="M${cx - w} ${cy} q${w} 9 ${w * 2} 0" fill="none" stroke="${STROKE}" stroke-width="${SW}" stroke-linecap="round"/>`;
}

/** 小鼻头点 */
function nose(cx, cy, r = 3.5) {
  return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#2a2a2a"/>`;
}

/* =====================================================
 * 1. 小狗：垂耳 + 吐小舌
 * =================================================== */
export function puppySvg(color = '#e8a86f') {
  return svg(
    `<ellipse cx="48" cy="100" rx="19" ry="32" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" transform="rotate(-14 48 100)"/>
<ellipse cx="152" cy="100" rx="19" ry="32" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" transform="rotate(14 152 100)"/>
${body(color)}
${cheek(68, 120)}
${cheek(132, 120)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 118)}
${smile(88, 126)}
<path d="M93 126 q7 8 14 0 q0 8 -7 11 q-7 -3 -7 -11 z" fill="#ff7a9c" stroke="${STROKE}" stroke-width="2.5" stroke-linejoin="round"/>`
  );
}

/* =====================================================
 * 2. 小猫：三角耳 + 3 根胡须
 * =================================================== */
export function catSvg(color = '#b8b8c8') {
  return svg(
    `<path d="M58 76 L46 42 L88 64 Z" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M142 76 L154 42 L112 64 Z" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M62 70 L54 50 L80 62 Z" fill="#ffc0d4"/>
<path d="M138 70 L146 50 L120 62 Z" fill="#ffc0d4"/>
${body(color)}
${cheek(66, 120)}
${cheek(134, 120)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 116)}
${smile(88, 124)}
<line x1="28" y1="110" x2="60" y2="112" stroke="${STROKE}" stroke-width="2.5" stroke-linecap="round"/>
<line x1="28" y1="120" x2="60" y2="120" stroke="${STROKE}" stroke-width="2.5" stroke-linecap="round"/>
<line x1="28" y1="130" x2="60" y2="126" stroke="${STROKE}" stroke-width="2.5" stroke-linecap="round"/>
<line x1="172" y1="110" x2="140" y2="112" stroke="${STROKE}" stroke-width="2.5" stroke-linecap="round"/>
<line x1="172" y1="120" x2="140" y2="120" stroke="${STROKE}" stroke-width="2.5" stroke-linecap="round"/>
<line x1="172" y1="130" x2="140" y2="126" stroke="${STROKE}" stroke-width="2.5" stroke-linecap="round"/>`
  );
}

/* =====================================================
 * 3. 兔子：两根长耳
 * =================================================== */
export function rabbitSvg(color = '#f5e6d3') {
  return svg(
    `<ellipse cx="82" cy="48" rx="12" ry="40" fill="${color}" stroke="${STROKE}" stroke-width="${SW}"/>
<ellipse cx="118" cy="48" rx="12" ry="40" fill="${color}" stroke="${STROKE}" stroke-width="${SW}"/>
<ellipse cx="82" cy="54" rx="5.5" ry="28" fill="#ffc0d4"/>
<ellipse cx="118" cy="54" rx="5.5" ry="28" fill="#ffc0d4"/>
${body(color)}
${cheek(68, 120)}
${cheek(132, 120)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 118)}
${smile(88, 126)}`
  );
}

/* =====================================================
 * 4. 仓鼠：小圆耳 + 圆腮
 * =================================================== */
export function hamsterSvg(color = '#e0a96d') {
  return svg(
    `<circle cx="64" cy="62" r="14" fill="${color}" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="136" cy="62" r="14" fill="${color}" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="64" cy="62" r="6" fill="#ffc0d4"/>
<circle cx="136" cy="62" r="6" fill="#ffc0d4"/>
${body(color)}
<circle cx="62" cy="126" r="17" fill="#f0c89a" opacity="0.85" stroke="${STROKE}" stroke-width="2.5"/>
<circle cx="138" cy="126" r="17" fill="#f0c89a" opacity="0.85" stroke="${STROKE}" stroke-width="2.5"/>
${eye(82, 98)}
${eye(118, 98)}
${nose(100, 116)}
<path d="M92 124 q8 6 16 0" fill="none" stroke="${STROKE}" stroke-width="${SW}" stroke-linecap="round"/>`
  );
}

/* =====================================================
 * 5. 小鸡：小鸡冠 + 橙尖嘴
 * =================================================== */
export function chickSvg(color = '#ffd54a') {
  return svg(
    `<path d="M88 52 q4 -14 12 -8 q0 8 -4 12 z" fill="#ff7a3a" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M104 56 q8 -12 12 -2 q-4 8 -8 8 z" fill="#ff7a3a" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
${body(color)}
${cheek(66, 120)}
${cheek(134, 120)}
${eye(82, 100)}
${eye(118, 100)}
<path d="M100 116 L84 124 L100 132 L116 124 Z" fill="#ff8c2a" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<line x1="84" y1="124" x2="116" y2="124" stroke="${STROKE}" stroke-width="3"/>`
  );
}

/* =====================================================
 * 6. 小狐狸：尖耳 + 大尾巴尖白
 * =================================================== */
export function foxSvg(color = '#e8784a') {
  return svg(
    `<path d="M152 140 c40 14 46 -22 24 -38 c-4 8 -2 18 -14 22 c-6 2 -8 8 -10 16 z" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M176 102 c20 8 16 24 4 24 c0 -8 -4 -16 -8 -20 z" fill="#ffffff" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M60 76 L48 40 L90 62 Z" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M140 76 L152 40 L110 62 Z" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M62 70 L54 50 L82 62 Z" fill="#ffc0d4"/>
<path d="M138 70 L146 50 L118 62 Z" fill="#ffc0d4"/>
${body(color)}
${cheek(68, 120)}
${cheek(132, 120)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 118)}
${smile(88, 126)}`
  );
}

/* =====================================================
 * 7. 熊猫：黑耳 + 黑眼圈
 * =================================================== */
export function pandaSvg(color = '#ffffff') {
  return svg(
    `<circle cx="60" cy="62" r="15" fill="#2b2b33" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="140" cy="62" r="15" fill="#2b2b33" stroke="${STROKE}" stroke-width="${SW}"/>
${body(color)}
<ellipse cx="80" cy="98" rx="19" ry="15" fill="#2b2b33" stroke="${STROKE}" stroke-width="${SW}" transform="rotate(-20 80 98)"/>
<ellipse cx="120" cy="98" rx="19" ry="15" fill="#2b2b33" stroke="${STROKE}" stroke-width="${SW}" transform="rotate(20 120 98)"/>
${cheek(66, 124)}
${cheek(134, 124)}
<circle cx="80" cy="100" r="12" fill="#ffffff" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="120" cy="100" r="12" fill="#ffffff" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="80" cy="102" r="8" fill="#2a2a2a"/>
<circle cx="120" cy="102" r="8" fill="#2a2a2a"/>
<circle cx="76" cy="99" r="3.5" fill="#ffffff"/>
<circle cx="116" cy="99" r="3.5" fill="#ffffff"/>
${nose(100, 118)}
${smile(88, 128)}`
  );
}

/* =====================================================
 * 8. 企鹅：白肚 + 橙嘴
 * =================================================== */
export function penguinSvg(color = '#2b2b3a') {
  return svg(
    `${body(color)}
<ellipse cx="100" cy="120" rx="38" ry="44" fill="#ffffff" stroke="${STROKE}" stroke-width="${SW}"/>
${cheek(64, 104)}
${cheek(136, 104)}
${eye(82, 90)}
${eye(118, 90)}
<path d="M100 104 L84 96 L100 88 L116 96 Z" fill="#ff8c2a" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<line x1="84" y1="96" x2="116" y2="96" stroke="${STROKE}" stroke-width="3"/>
<path d="M86 152 q14 6 28 0" fill="#ff8c2a" stroke="${STROKE}" stroke-width="${SW}" stroke-linecap="round"/>`
  );
}

/* =====================================================
 * 9. 小恐龙：背刺 + 小尾
 * =================================================== */
export function dinoSvg(color = '#6fbf6f') {
  return svg(
    `<path d="M152 136 q24 -2 22 -22 q-8 6 -12 -2 q-2 14 -12 18 z" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M70 54 L78 36 L86 54 Z" fill="#5fa85f" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M88 50 L96 32 L104 50 Z" fill="#5fa85f" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M106 52 L114 36 L122 54 Z" fill="#5fa85f" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
${body(color)}
${cheek(68, 120)}
${cheek(132, 120)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 118)}
${smile(88, 126)}`
  );
}

/* =====================================================
 * 10. 独角兽：彩虹鬃 + 独角
 * =================================================== */
function maneBit(x, y, c) {
  return `<path d="M${x} ${y} q16 -6 20 8 q-8 2 -8 14 q-12 -8 -14 -2 z" fill="${c}" stroke="${STROKE}" stroke-width="2.5" stroke-linejoin="round"/>`;
}
export function unicornSvg(color = '#f0c4f5') {
  return svg(
    `${maneBit(142, 50, '#ff5a7a')}
${maneBit(148, 64, '#ff8c3a')}
${maneBit(150, 78, '#ffd23a')}
${maneBit(148, 92, '#5ad17a')}
${maneBit(142, 106, '#4ab3ff')}
<path d="M100 36 L92 64 L108 64 Z" fill="#fff7c4" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<line x1="98" y1="42" x2="102" y2="60" stroke="${STROKE}" stroke-width="2.5"/>
<line x1="100" y1="40" x2="100" y2="62" stroke="${STROKE}" stroke-width="2.5"/>
${body(color)}
${cheek(68, 120)}
${cheek(132, 120)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 118)}
${smile(88, 126)}`
  );
}

/* =====================================================
 * 11. 小狮子：圆鬃毛
 * =================================================== */
export function lionSvg(color = '#e8a848') {
  return svg(
    `<circle cx="100" cy="110" r="84" fill="#c4761f" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="38" cy="70" r="14" fill="#c4761f" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="162" cy="70" r="14" fill="#c4761f" stroke="${STROKE}" stroke-width="${SW}"/>
${body(color)}
${cheek(66, 120)}
${cheek(134, 120)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 118)}
<path d="M90 126 q10 9 20 0" fill="none" stroke="${STROKE}" stroke-width="${SW}" stroke-linecap="round"/>
<line x1="100" y1="118" x2="100" y2="124" stroke="${STROKE}" stroke-width="3" stroke-linecap="round"/>`
  );
}

/* =====================================================
 * 12. 老虎：黑条纹
 * =================================================== */
export function tigerSvg(color = '#f4a83a') {
  return svg(
    `<circle cx="68" cy="58" r="12" fill="${color}" stroke="${STROKE}" stroke-width="${SW}"/>
<circle cx="132" cy="58" r="12" fill="${color}" stroke="${STROKE}" stroke-width="${SW}"/>
${body(color)}
<path d="M100 56 q0 12 0 20" fill="none" stroke="#2b2b33" stroke-width="5" stroke-linecap="round"/>
<path d="M72 72 q-10 4 -6 16" fill="none" stroke="#2b2b33" stroke-width="5" stroke-linecap="round"/>
<path d="M128 72 q10 4 6 16" fill="none" stroke="#2b2b33" stroke-width="5" stroke-linecap="round"/>
<path d="M56 110 q-8 4 -4 16" fill="none" stroke="#2b2b33" stroke-width="5" stroke-linecap="round"/>
<path d="M144 110 q8 4 16" fill="none" stroke="#2b2b33" stroke-width="5" stroke-linecap="round"/>
${cheek(64, 122)}
${cheek(136, 122)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 118)}
${smile(88, 126)}`
  );
}

/* =====================================================
 * 13. 神龙：小翅膀 + 龙角
 * =================================================== */
export function dragonSvg(color = '#5fa8e8') {
  return svg(
    `<path d="M48 92 q-26 -6 -22 -26 q12 8 22 2 q-6 8 2 14 q8 -6 4 8 q-6 8 -6 2 z" fill="#9fd0ff" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M152 92 q26 -6 22 -26 q-12 8 -22 2 q6 8 -2 14 q-8 -2 -4 8 q6 8 6 2 z" fill="#9fd0ff" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M82 54 q-8 -16 2 -24 q4 8 2 16 q4 -2 2 8 z" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M118 54 q8 -16 -2 -24 q-4 8 -2 16 q-4 -2 -2 8 z" fill="${color}" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
${body(color)}
${cheek(68, 120)}
${cheek(132, 120)}
${eye(80, 98)}
${eye(120, 98)}
${nose(100, 118)}
${smile(88, 126)}`
  );
}

/* =====================================================
 * 14. 凤凰：火冠 + 翅膀
 * =================================================== */
export function phoenixSvg(color = '#e8542a') {
  return svg(
    `<path d="M46 96 q-24 -2 -18 -22 q8 8 18 4 q-6 8 2 14 q8 -6 4 8 q-8 4 -6 -4 z" fill="#ffb14a" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M154 96 q24 -2 18 -22 q-8 8 -18 4 q6 8 -2 14 q-8 -6 -4 8 q8 4 6 -4 z" fill="#ffb14a" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M100 46 q-8 -10 2 -22 q4 8 0 14 q6 -6 8 0 q-2 10 -8 14 q-2 -6 -2 -6 z" fill="#ffb14a" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<path d="M102 42 q6 -8 12 -4 q-2 6 -6 6 q2 -4 -2 -2 q-2 4 -4 0 z" fill="#ffd84a"/>
${body(color)}
${cheek(68, 120)}
${cheek(132, 120)}
${eye(80, 98)}
${eye(120, 98)}
<path d="M100 112 L92 120 L100 128 L108 120 Z" fill="#ffb14a" stroke="${STROKE}" stroke-width="${SW}" stroke-linejoin="round"/>
<line x1="92" y1="120" x2="108" y2="120" stroke="${STROKE}" stroke-width="3"/>
<path d="M88 134 q12 6 24 0" fill="none" stroke="${STROKE}" stroke-width="${SW}" stroke-linecap="round"/>`
  );
}

/* =====================================================
 * 分发 & 默认色
 * =================================================== */
const PET_MAP = {
  '小狗': puppySvg, 'puppy': puppySvg, 'dog': puppySvg,
  '小猫': catSvg, 'cat': catSvg,
  '兔子': rabbitSvg, 'rabbit': rabbitSvg,
  '仓鼠': hamsterSvg, 'hamster': hamsterSvg,
  '小鸡': chickSvg, 'chick': chickSvg,
  '小狐狸': foxSvg, 'fox': foxSvg,
  '熊猫': pandaSvg, 'panda': pandaSvg,
  '企鹅': penguinSvg, 'penguin': penguinSvg,
  '小恐龙': dinoSvg, 'dino': dinoSvg,
  '独角兽': unicornSvg, 'unicorn': unicornSvg,
  '小狮子': lionSvg, 'lion': lionSvg,
  '老虎': tigerSvg, 'tiger': tigerSvg,
  '神龙': dragonSvg, 'dragon': dragonSvg,
  '凤凰': phoenixSvg, 'phoenix': phoenixSvg,
};

const DEFAULT_COLORS = {
  '小狗': '#e8a86f', 'puppy': '#e8a86f', 'dog': '#e8a86f',
  '小猫': '#b8b8c8', 'cat': '#b8b8c8',
  '兔子': '#f5e6d3', 'rabbit': '#f5e6d3',
  '仓鼠': '#e0a96d', 'hamster': '#e0a96d',
  '小鸡': '#ffd54a', 'chick': '#ffd54a',
  '小狐狸': '#e8784a', 'fox': '#e8784a',
  '熊猫': '#ffffff', 'panda': '#ffffff',
  '企鹅': '#2b2b3a', 'penguin': '#2b2b3a',
  '小恐龙': '#6fbf6f', 'dino': '#6fbf6f',
  '独角兽': '#f0c4f5', 'unicorn': '#f0c4f5',
  '小狮子': '#e8a848', 'lion': '#e8a848',
  '老虎': '#f4a83a', 'tiger': '#f4a83a',
  '神龙': '#5fa8e8', 'dragon': '#5fa8e8',
  '凤凰': '#e8542a', 'phoenix': '#e8542a',
};

/** 按物种名取 SVG（支持中英文 key） */
export function getPetSvg(species, color) {
  const key = String(species || '');
  const fn = PET_MAP[key];
  if (!fn) return puppySvg(color);
  return fn(color || DEFAULT_COLORS[key] || '#e8a86f');
}

/** 取某物种默认主色 */
export function petDefaultColor(species) {
  const key = String(species || '');
  return DEFAULT_COLORS[key] || '#e8a86f';
}

export { svg, body, eye, cheek, smile, nose };
