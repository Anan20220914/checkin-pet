// views/home.js — 首页：决斗主舞台 + 本周战果 + 成就徽章 + 周礼物

import { getState, update } from '../store.js';
import { isDailyDuelDone, recordDailyDuel, getStudyDoneCount } from '../tasks.js';
import { getActivePet, petStats, setPetHp, clearBuffs } from '../pets.js';
import { MONSTER_TIERS, STUDY_MIN_FOR_DUEL, RARITY_NAME, RARITY_COLOR, WEEKLY_GIFTS } from '../db2.js';
import { esc, relDay, todayKey, dayOffset } from '../utils.js';
import { showOverlay, closeOverlay, switchTab, toast, celebrate } from '../app.js';
import { runBattle, winReward, shouldDropEgg } from '../battle.js';
import { addEgg } from '../daily.js';
import { renderPet, attackMotion } from '../pet-render.js';
import { getZombieSvg } from '../zombie-svgs.js';
import { getGiftSvg } from '../gift-svgs.js';
import { openPetDex } from './pets.js';
import { getAchievementList, markSeen } from '../achievements.js';
import { currentGiftPreview, giftHistory } from '../weekly.js';

const el = () => document.getElementById('view-home');

export function renderHome() {
  const s = getState();
  const monster = s.monsters.today;
  const pet = getActivePet();
  const stats = pet ? petStats(pet) : null;
  const dueled = isDailyDuelDone();
  const studyDone = getStudyDoneCount();

  let html = '';

  // === 决斗主舞台 ===
  const zSvg = (monster && getZombieSvg(monster.tier)) || '';
  html += `
    <div class="arena-card">
      <div class="arena-bg"></div>
      <div class="arena-deco">
        <div class="cloud" style="top:12px;left:8%">☁️</div>
        <div class="cloud c2" style="top:24px;right:18%">☁️</div>
        <div class="arena-mushroom">🍄</div>
        <div class="arena-pipe"></div>
      </div>
      <div class="arena-stage">
        <div class="arena-pet">
          ${pet ? renderPet(pet, 'md') : '<div class="empty-emoji">🐾</div>'}
          <div class="arena-name">${pet ? esc(pet.species) : '无宠物'}</div>
          ${pet ? `<div class="arena-hp"><div class="fill" style="width:${(pet.currentHp/pet.hp*100)}%"></div></div><div class="arena-hp-text">体力 ${pet.currentHp}/${pet.hp}</div>` : ''}
        </div>
        <div class="arena-vs">VS</div>
        <div class="arena-monster">
          ${monster ? `<div class="arena-monster-svg">${zSvg}</div>
          <div class="arena-name">${esc(monster.name)}</div>
          <div class="arena-hp"><div class="fill monster" style="width:100%"></div></div>
          <div class="arena-hp-text">Tier ${monster.tier} · HP ${monster.hp}</div>` : '今日怪兽未刷新'}
        </div>
      </div>
      <div class="arena-ground"></div>
      <div class="arena-btn-wrap">
        ${duelBtn(dueled, studyDone, pet, monster)}
      </div>
    </div>
  `;

  // === 本周战果 ===
  html += `<div class="section-title">📅 本周战果</div>`;
  html += `<div class="week-strip">`;
  const week = weekDays();
  for (const d of week) {
    const b = (s.battles || []).find(x => x.date === d.key);
    const c = s.checkins[d.key];
    const checked = c ? Object.keys(c).filter(k => c[k] && c[k].done).length : 0;
    const today = d.key === todayKey();
    let cls = today ? 'today' : '';
    let icon = '·', sub = '-';
    if (b) {
      cls = (b.result === 'win' ? 'win' : 'lose') + (today ? ' today' : '');
      icon = b.result === 'win' ? '🏆' : '😅';
      sub = b.result === 'win' ? '胜' : '负';
    } else if (checked > 0) {
      cls = 'checked' + (today ? ' today' : '');
      icon = '✅'; sub = checked + '项';
    } else if (today) {
      icon = '👉'; sub = '今天';
    }
    html += `
      <div class="week-day ${cls}">
        <div class="wd-name">${d.label}</div>
        <div class="wd-icon">${icon}</div>
        <div class="wd-sub">${sub}</div>
      </div>
    `;
  }
  html += `</div>`;

  // === 成就徽章 + 周礼物 入口 ===
  const achList = getAchievementList();
  const achUnlocked = achList.filter(a => a.unlocked);
  const g = currentGiftPreview();
  html += `
    <div class="home-row">
      <div class="home-mini ach" id="openAch">
        <div class="hm-emoji">🏅</div>
        <div class="hm-name">成就</div>
        <div class="hm-sub">${achUnlocked.length}/${achList.length} 已解锁</div>
      </div>
      <div class="home-mini gift" id="openGift">
        <div class="hm-emoji">🎁</div>
        <div class="hm-name">周礼物</div>
        <div class="hm-sub">${g.settled ? g.name : '周日决斗后揭晓'}</div>
      </div>
    </div>
    <div class="home-row">
      <div class="home-mini" id="homeDexBtn">
        <div class="hm-emoji">📖</div>
        <div class="hm-name">宠物图鉴</div>
      </div>
      <div class="home-mini" id="openZomDex">
        <div class="hm-emoji">🧟</div>
        <div class="hm-name">僵尸图鉴</div>
      </div>
    </div>
  `;

  el().innerHTML = html;

  // 绑定
  const goDuel = el().querySelector('#goDuel');
  if (goDuel && !goDuel.disabled) goDuel.onclick = () => startDailyDuel();
  el().querySelector('#openAch').onclick = openAchievements;
  el().querySelector('#openGift').onclick = openWeeklyGift;
  el().querySelector('#homeDexBtn').onclick = () => openPetDex();
  el().querySelector('#openZomDex').onclick = openZombieDex;
}

function duelBtn(dueled, studyDone, pet, monster) {
  if (dueled) return `<button class="btn big block" disabled>今日已对决 ✓</button>`;
  if (!monster) return `<button class="btn big block" disabled>怪兽未刷新</button>`;
  if (!pet || pet.currentHp <= 0) return `<button class="btn big block" disabled>宠物体力不足，去商店买食物</button>`;
  return `<button class="btn big block" id="goDuel">⚔️ 开始决斗</button>`;
}

/** 本周 7 天键+标签 */
function weekDays() {
  const today = new Date();
  const day = today.getDay(); // 0=周日
  const monday = day === 0 ? -6 : 1 - day;
  const labels = ['一','二','三','四','五','六','日'];
  const arr = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + monday + i);
    const y = d.getFullYear(), m = String(d.getMonth()+1).padStart(2,'0'), dd = String(d.getDate()).padStart(2,'0');
    arr.push({ key: `${y}-${m}-${dd}`, label: labels[i] });
  }
  return arr;
}

/* ============ 每日对决逻辑（从 battle.js view 迁移） ============ */
function startDailyDuel() {
  const s = getState();
  const pet = getActivePet();
  const monster = s.monsters.today;
  if (!pet || !monster) { toast('数据异常'); return; }
  if (pet.currentHp <= 0) { toast('宠物体力不足，先恢复'); return; }
  const result = runBattle(pet, monster);
  playBattleAnimation(pet, monster, result, () => settleDailyDuel(pet, monster, result));
}

function playBattleAnimation(pet, monster, result, onDone) {
  const log = result.log;
  let i = 0;
  const petMaxHp = pet.hp;
  const monMaxHp = monster.hp;
  const overlay = document.getElementById('overlay');
  const card = document.getElementById('overlayCard');
  const zSvg = getZombieSvg(monster.tier);

  const render = (idx) => {
    if (idx >= log.length) { onDone(); return; }
    const entry = log[idx];
    const petHp = entry.petHp ?? petMaxHp;
    const monHp = entry.monHp ?? monMaxHp;
    const petPct = (petHp / petMaxHp) * 100;
    const monPct = (monHp / monMaxHp) * 100;
    const logHtml = log.slice(0, idx + 1).map(e => `<div class="line ${e.actor}">${esc(e.text)}</div>`).join('');

    card.innerHTML = `
      <div class="quiz-head"><span class="quiz-title">⚔️ 决斗</span><span class="quiz-count">回合 ${Math.min(idx,30)}/30</span></div>
      <div class="battle-stage">
        <div class="bs-vs">
          <div class="bs-side pet">
            <div style="height:72px;display:flex;align-items:flex-end;justify-content:center;position:relative" class="${entry.actor==='pet'?attackMotion(pet):(entry.actor==='monster'?'hit-shake hit-flash':'')}">${renderPet(pet,'sm')}${entry.actor==='monster'?'<div class="dmg-pop">-'+(entry.text.match(/(\d+)/)?.[1]||'')+'</div>':''}</div>
            <div class="bs-name">${esc(pet.species)}</div>
            <div class="bs-hpbar"><div class="fill" style="width:${petPct}%"></div></div>
            <div style="font-size:10px">${petHp} HP</div>
          </div>
          <div class="bs-vs-label">VS</div>
          <div class="bs-side">
            <div style="height:72px;display:flex;align-items:flex-end;justify-content:center;position:relative" class="${entry.actor==='pet'?'hit-shake hit-flash':''}">
              <div class="monster-svg">${zSvg}</div>
              ${entry.actor==='pet'?'<div class="attack-fx">💥</div><div class="dmg-pop">-'+(entry.text.match(/(\d+)/)?.[1]||'')+'</div>':''}
            </div>
            <div class="bs-name">${esc(monster.name)}</div>
            <div class="bs-hpbar"><div class="fill" style="width:${monPct}%"></div></div>
            <div style="font-size:10px">${monHp} HP</div>
          </div>
        </div>
      </div>
      <div class="battle-log" id="duelLog">${logHtml}</div>
    `;
    overlay.hidden = false;
    const logEl = card.querySelector('#duelLog');
    if (logEl) logEl.scrollTop = logEl.scrollHeight;
    setTimeout(() => render(idx + 1), idx === 0 ? 700 : 900);
  };
  render(0);
}

function settleDailyDuel(pet, monster, result) {
  const s = getState();
  const won = result.result === 'win';
  let reward = 0, dropEgg = false;
  update(st => {
    const p = st.pets.find(pp => pp.id === pet.id);
    if (p) { p.currentHp = Math.max(won ? 1 : 0, result.petHpLeft); p.buffs = []; }
    st.battles.push({ id: 'b_' + Date.now().toString(36), date: monster.date, petId: pet.id, monsterId: monster.id, result: result.result, turns: result.turns, dropEgg: false, earnedPoints: 0 });
    st.stats.totalBattles++;
    if (!st.pokedex.monsters.includes(monster.tier)) st.pokedex.monsters.push(monster.tier);
    if (won) {
      st.stats.streak = (st.stats.streak || 0) + 1;
      if (st.stats.streak > st.stats.bestStreak) st.stats.bestStreak = st.stats.streak;
      st.stats.totalWins++;
      reward = winReward(monster.tier);
      dropEgg = shouldDropEgg(monster.tier, st.stats.noDropStreak || 0);
      st.stats.noDropStreak = dropEgg ? 0 : (st.stats.noDropStreak || 0) + 1;
    } else { st.stats.streak = 0; reward = 2; }
    st.wallet.points += reward; st.wallet.totalEarned += reward;
  });
  if (dropEgg) addEgg('daily-duel');
  recordDailyDuel({ result: result.result, dropEgg, reward, monsterId: monster.id });
  if (won) celebrate('决斗胜利！', dropEgg ? `掉落宠物蛋🥚 +${reward}金币` : `连胜${getState().stats.streak} +${reward}金币`);

  const streakAfter = getState().stats.streak;
  if (won) {
    closeOverlay();
    const sub = dropEgg ? `获得 ${reward} 金币 · 掉落宠物蛋🥚` : `获得 ${reward} 金币 · 连胜 ${streakAfter}`;
    celebrate('决斗胜利', sub);
    setTimeout(()=>switchTab('home'),100);
    return;
  }
  const html = `<h2>😴 再接再厉</h2><div class="desc">没能击败 ${monster.name}，连胜归零 · 获得 ${reward} 金币</div><button class="btn block" id="duelPet">好的</button>`;
  showOverlay(html, { onMount: c => {
    c.querySelector('#duelPet').onclick = () => { closeOverlay(); switchTab('home'); };
  }});
}

/* ============ 图鉴/成就/礼物 浮层 ============ */
function openZombieDex() {
  const unlocked = (getState().pokedex?.monsters || []);
  let grid = '<div class="dex-grid">';
  for (const z of MONSTER_TIERS) {
    const has = unlocked.includes(z.tier);
    grid += `<div class="dex-cell ${has?'':'locked'}">
      ${has ? `<div class="dex-svg">${getZombieSvg(z.tier)}</div>` : `<div class="dex-emoji">🧟</div>`}
      <div class="dex-name">${has ? z.name : '？？'}</div>
    </div>`;
  }
  grid += '</div>';
  showOverlay(`<h2>🧟 僵尸图鉴</h2><div class="desc">已解锁 ${unlocked.length}/${MONSTER_TIERS.length}</div>${grid}<button class="btn secondary block" id="close" style="margin-top:12px">关闭</button>`, { onMount: c => { c.querySelector('#close').onclick = closeOverlay; } });
}

function openAchievements() {
  const list = getAchievementList();
  let html = `<h2>🏅 成就徽章</h2><div class="desc">已解锁 ${list.filter(a=>a.unlocked).length}/${list.length}</div>`;
  for (const a of list) {
    html += `<div class="ach-item ${a.unlocked?'unlocked':'locked'}">
      <div class="ach-icon">${a.icon}</div>
      <div class="ach-body"><div class="ach-name">${a.name}</div><div class="ach-desc">${a.desc}</div></div>
      <div class="ach-status">${a.unlocked?'✓':'🔒'}</div>
    </div>`;
  }
  html += `<button class="btn secondary block" id="close" style="margin-top:12px">关闭</button>`;
  showOverlay(html, { onMount: c => { c.querySelector('#close').onclick = closeOverlay; } });
  markSeen();
}

function openWeeklyGift() {
  const g = currentGiftPreview();
  const history = giftHistory();
  let heroHtml = '';
  if (g.settled) {
    const segs = WEEKLY_GIFTS.map(w => `<div class="seg ${g.tier >= w.tier ? 'on' : ''}"></div>`).join('');
    heroHtml = `<div style="font-weight:800;font-size:18px">${g.name}</div>
      <div class="gift-svg">${getGiftSvg(g.tier)}</div>
      <div class="gift-tier">Tier ${g.tier}${g.brand ? ' · '+g.brand : ''}</div>
      <div class="gift-tier-bar">${segs}</div>
      <div class="hint">本周已结算 · 胜 ${g.wins} 场</div>`;
  } else {
    heroHtml = `<div style="font-size:64px">🎁</div>
      <div style="font-weight:800;font-size:18px;margin-top:6px">周日决斗后揭晓</div>
      <div class="hint">本周已胜 ${g.wins} 场<br>胜得越多礼物越好（自行车→航空母舰）</div>`;
  }
  let html = `<h2>🎁 每周日礼物</h2><div class="gift-hero">${heroHtml}</div>
    <div class="section-title">📜 礼物记录</div>`;
  if (!history.length) html += `<div class="empty"><span class="emoji">📭</span>还没有收到过礼物</div>`;
  for (const h of history) html += `<div class="gift-row"><span class="g-emoji">🎁</span><span>${h.name} · 胜${h.wins}场</span></div>`;
  html += `<button class="btn secondary block" id="close" style="margin-top:12px">关闭</button>`;
  showOverlay(html, { onMount: c => { c.querySelector('#close').onclick = closeOverlay; } });
}
