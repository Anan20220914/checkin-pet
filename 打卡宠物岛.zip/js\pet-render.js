// pet-render.js — 宠物渲染：emoji + 背景色 + 贴纸 + 配饰 + 装备

import { findSpecies, ACCESSORIES, SHOP_WEAPONS } from './db2.js';

/**
 * 渲染一只宠物为 HTML（emoji + 背景色 + 贴纸 + 配饰 + 装备）
 * @param pet 宠物对象 { species, bgColor, sticker, accessories, equippedWeapon, emoji }
 * @param size 'lg'|'md'|''|'sm'
 */
export function renderPet(pet, size = '') {
  if (!pet) return '';
  const sp = findSpecies(pet.species);
  const sizeCls = size === 'lg' ? 'lg' : (size === 'md' ? 'md' : (size === 'sm' ? 'sm' : ''));
  const emoji = (sp && sp.emoji) || pet.emoji || '🐾';
  const bgColor = pet.bgColor || '#fff8e7';

  const accs = (pet.accessories || []).map(id => ACCESSORIES.find(a => a.id === id)).filter(Boolean);
  let layers = '';
  for (const a of accs) {
    layers += `<div class="acc-layer slot-${a.slot}"><img src="${a.img}" alt="" onerror="this.parentNode.style.display='none'"></div>`;
  }

  // 贴纸（在宠物旁边的小装饰 emoji）
  let stickerLayer = '';
  if (pet.sticker) {
    stickerLayer = `<div class="pet-sticker">${pet.sticker}</div>`;
  }

  // 装备武器：显示武器(右手) + 盾牌(左手)
  let weaponLayer = '';
  if (pet.equippedWeapon) {
    const wp = SHOP_WEAPONS.find(w => w.id === pet.equippedWeapon);
    const wpEmoji = wp ? wp.emoji : '🗡️';
    weaponLayer = `
      <div class="weapon-layer sword"><span>${wpEmoji}</span></div>
      <div class="weapon-layer shield"><span>🛡️</span></div>
    `;
  }

  return `<div class="pet-img-wrap pet-armed">
    <div class="pet-emoji ${sizeCls}" style="background:${bgColor}">${emoji}</div>
    ${stickerLayer}
    ${layers}
    ${weaponLayer}
  </div>`;
}

/** 取某宠物的所有可选色板 */
export function getPalette(pet) {
  const sp = findSpecies(pet.species);
  return (sp && sp.palette) || [{ name: '原色', color: petDefaultColor(pet.species) }];
}

/** 取动物攻击动作类名 */
export function attackMotion(pet) {
  const sp = findSpecies(pet.species);
  return sp ? `attack-${sp.motion}` : 'attack-lunge';
}

/** 取动物攻击动作描述 */
export function attackName(pet) {
  const sp = findSpecies(pet.species);
  return sp ? sp.attack : '攻击';
}
