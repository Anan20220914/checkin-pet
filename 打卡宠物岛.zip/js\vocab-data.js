// vocab-data.js — 识字字库 + 英语词库
// 识字字库按统编版语文一年级上册识字顺序整理（公开课程标准，非版权书复制）
// 英语词库分 6 类，每词配 category 与简笔画 SVG key（svg-art.js 据此画图）

/* ============================================================
 * 识字字库：分阶段（每阶段约 25-30 字），从最常用字起步
 * 覆盖一年级上册高频字，可扩展
 * ========================================================== */
export const CHINESE_STAGES = [
  // 第1阶段：基础笔画与身体字（去掉太简单的数字）
  ['口','目','耳','手','足','大','小','上','下','左','右','人','天','地','日','月','木','水','火','山','石','田','土','云','雨'],
  // 第2阶段：自然与天象
  ['日','月','水','火','山','石','田','土','云','雨','风','天','地','星','光','电','木','禾','米','竹','花','草','虫','鸟','鱼'],
  // 第3阶段：人称与家庭
  ['我','你','他','她','们','爸','妈','爷','奶','哥','姐','弟','妹','儿','子','女','男','老','师','友','家','人','口','心','头'],
  // 第4阶段：动作与身体
  ['走','跑','跳','飞','看','听','说','读','写','画','吃','喝','打','拿','放','坐','立','起','来','去','出','入','开','关','买'],
  // 第5阶段：生活与器物
  ['书','本','笔','纸','字','词','车','马','牛','羊','犬','衣','帽','鞋','伞','灯','钟','床','桌','椅','门','窗','碗','筷','刀'],
  // 第6阶段：颜色与形状
  ['红','黄','蓝','绿','白','黑','紫','灰','圆','方','长','短','高','低','多','少','新','旧','好','坏','美','丑','快','慢','远'],
  // 第7阶段：时间与方位
  ['今','明','昨','年','早','晚','春','夏','秋','冬','东','西','南','北','前','后','里','外','早','晚','中','间','旁','边','对'],
  // 第8阶段：情感与品质
  ['爱','喜','乐','笑','哭','怒','怕','想','知','会','能','要','给','帮','让','学','问','答','真','假','对','错','同','一','起'],
];

/* ============================================================
 * 英语词库：6 类，每词 { word, cn, svg } svg 为 svg-art.js 的 key
 * ========================================================== */
export const ENGLISH_WORDS = {
  shape: [
    { word: 'circle', cn: '圆形', svg: 'circle' },
    { word: 'square', cn: '方形', svg: 'square' },
    { word: 'triangle', cn: '三角形', svg: 'triangle' },
    { word: 'star', cn: '星星', svg: 'star' },
    { word: 'heart', cn: '心形', svg: 'heart' },
    { word: 'diamond', cn: '菱形', svg: 'diamond' },
    { word: 'oval', cn: '椭圆', svg: 'oval' },
    { word: 'cross', cn: '十字', svg: 'cross' },
  ],
  weather: [
    { word: 'sun', cn: '太阳', svg: 'sun' },
    { word: 'rain', cn: '雨', svg: 'rain' },
    { word: 'cloud', cn: '云', svg: 'cloud' },
    { word: 'snow', cn: '雪', svg: 'snow' },
    { word: 'wind', cn: '风', svg: 'wind' },
    { word: 'rainbow', cn: '彩虹', svg: 'rainbow' },
    { word: 'moon', cn: '月亮', svg: 'moon' },
    { word: 'star', cn: '星星', svg: 'star' },
  ],
  number: [
    { word: 'one', cn: '一', svg: 'n1' },
    { word: 'two', cn: '二', svg: 'n2' },
    { word: 'three', cn: '三', svg: 'n3' },
    { word: 'four', cn: '四', svg: 'n4' },
    { word: 'five', cn: '五', svg: 'n5' },
    { word: 'six', cn: '六', svg: 'n6' },
    { word: 'seven', cn: '七', svg: 'n7' },
    { word: 'eight', cn: '八', svg: 'n8' },
    { word: 'nine', cn: '九', svg: 'n9' },
    { word: 'ten', cn: '十', svg: 'n10' },
  ],
  daily: [
    { word: 'cup', cn: '杯子', svg: 'cup' },
    { word: 'bowl', cn: '碗', svg: 'bowl' },
    { word: 'spoon', cn: '勺子', svg: 'spoon' },
    { word: 'toothbrush', cn: '牙刷', svg: 'toothbrush' },
    { word: 'towel', cn: '毛巾', svg: 'towel' },
    { word: 'comb', cn: '梳子', svg: 'comb' },
    { word: 'clock', cn: '钟', svg: 'clock' },
    { word: 'lamp', cn: '灯', svg: 'lamp' },
    { word: 'umbrella', cn: '雨伞', svg: 'umbrella' },
    { word: 'book', cn: '书', svg: 'book' },
    { word: 'pen', cn: '笔', svg: 'pen' },
    { word: 'bag', cn: '包', svg: 'bag' },
    { word: 'bottle', cn: '瓶子', svg: 'bottle' },
    { word: 'plate', cn: '盘子', svg: 'plate' },
  ],
  vehicle: [
    { word: 'car', cn: '小汽车', svg: 'car' },
    { word: 'bus', cn: '公交车', svg: 'bus' },
    { word: 'bike', cn: '自行车', svg: 'bike' },
    { word: 'train', cn: '火车', svg: 'train' },
    { word: 'plane', cn: '飞机', svg: 'plane' },
    { word: 'ship', cn: '船', svg: 'ship' },
    { word: 'boat', cn: '小船', svg: 'boat' },
    { word: 'subway', cn: '地铁', svg: 'subway' },
    { word: 'taxi', cn: '出租车', svg: 'taxi' },
    { word: 'truck', cn: '卡车', svg: 'truck' },
    { word: 'ambulance', cn: '救护车', svg: 'ambulance' },
    { word: 'fire', cn: '消防车', svg: 'fire' },
  ],
};

/** 英语分类中文名 */
export const ENGLISH_CATEGORIES = {
  color: '颜色',
  shape: '形状',
  weather: '天气',
  number: '数字',
  daily: '日用品',
  vehicle: '交通工具',
};

/** 日常短句（启蒙常用语，每日1句循环记忆） */
export const ENGLISH_PHRASES = [
  { word: 'Good morning', cn: '早上好', svg: 'sun' },
  { word: 'Good night', cn: '晚上好', svg: 'moon' },
  { word: 'Hello', cn: '你好', svg: 'star' },
  { word: 'Thank you', cn: '谢谢', svg: 'heart' },
  { word: 'Goodbye', cn: '再见', svg: 'wind' },
  { word: 'Sorry', cn: '对不起', svg: 'cloud' },
  { word: 'I love you', cn: '我爱你', svg: 'heart' },
  { word: 'Yes', cn: '是的', svg: 'star' },
  { word: 'No', cn: '不是', svg: 'cross' },
];

/** 平铺所有英语单词（带 category） */
export const ALL_ENGLISH_WORDS = (() => {
  const all = [];
  for (const [cat, list] of Object.entries(ENGLISH_WORDS)) {
    for (const w of list) all.push({ ...w, category: cat });
  }
  return all;
})();

/** 按 svg key 取英语词（用于反向查找） */
export function findWordBySvg(svg) {
  return ALL_ENGLISH_WORDS.find(w => w.svg === svg) || null;
}

/* ============================================================
 * 古诗词库：参考 2026 最新版浙江语文教材（统编版）古诗顺序整理
 * 公开课程标准，按一至六年级出现顺序分阶段。key 用诗题。
 * ========================================================== */
export const POEMS = [
  // 第1阶段（一年级上）
  { title: '咏鹅', author: '骆宾王', text: '鹅，鹅，鹅，曲项向天歌。白毛浮绿水，红掌拨清波。', stage: 0 },
  { title: '江南', author: '汉乐府', text: '江南可采莲，莲叶何田田。鱼戏莲叶间。鱼戏莲叶东，鱼戏莲叶西，鱼戏莲叶南，鱼戏莲叶北。', stage: 0 },
  { title: '画', author: '王维', text: '远看山有色，近听水无声。春去花还在，人来鸟不惊。', stage: 0 },
  // 第2阶段（一年级下）
  { title: '春晓', author: '孟浩然', text: '春眠不觉晓，处处闻啼鸟。夜来风雨声，花落知多少。', stage: 1 },
  { title: '赠汪伦', author: '李白', text: '李白乘舟将欲行，忽闻岸上踏歌声。桃花潭水深千尺，不及汪伦送我情。', stage: 1 },
  { title: '静夜思', author: '李白', text: '床前明月光，疑是地上霜。举头望明月，低头思故乡。', stage: 1 },
  { title: '寻隐者不遇', author: '贾岛', text: '松下问童子，言师采药去。只在此山中，云深不知处。', stage: 1 },
  { title: '池上', author: '白居易', text: '小娃撑小艇，偷采白莲回。不解藏踪迹，浮萍一道开。', stage: 1 },
  { title: '小池', author: '杨万里', text: '泉眼无声惜细流，树阴照水爱晴柔。小荷才露尖尖角，早有蜻蜓立上头。', stage: 1 },
  // 第3阶段（二年级上）
  { title: '梅花', author: '王安石', text: '墙角数枝梅，凌寒独自开。遥知不是雪，为有暗香来。', stage: 2 },
  { title: '登鹳雀楼', author: '王之涣', text: '白日依山尽，黄河入海流。欲穷千里目，更上一层楼。', stage: 2 },
  { title: '望庐山瀑布', author: '李白', text: '日照香炉生紫烟，遥看瀑布挂前川。飞流直下三千尺，疑是银河落九天。', stage: 2 },
  { title: '江雪', author: '柳宗元', text: '千山鸟飞绝，万径人踪灭。孤舟蓑笠翁，独钓寒江雪。', stage: 2 },
  { title: '夜宿山寺', author: '李白', text: '危楼高百尺，手可摘星辰。不敢高声语，恐惊天上人。', stage: 2 },
  { title: '敕勒歌', author: '北朝民歌', text: '敕勒川，阴山下。天似穹庐，笼盖四野。天苍苍，野茫茫，风吹草低见牛羊。', stage: 2 },
  // 第4阶段（二年级下）
  { title: '村居', author: '高鼎', text: '草长莺飞二月天，拂堤杨柳醉春烟。儿童散学归来早，忙趁东风放纸鸢。', stage: 3 },
  { title: '咏柳', author: '贺知章', text: '碧玉妆成一树高，万条垂下绿丝绦。不知细叶谁裁出，二月春风似剪刀。', stage: 3 },
  { title: '草', author: '白居易', text: '离离原上草，一岁一枯荣。野火烧不尽，春风吹又生。', stage: 3 },
  { title: '晓出净慈寺送林子方', author: '杨万里', text: '毕竟西湖六月中，风光不与四时同。接天莲叶无穷碧，映日荷花别样红。', stage: 3 },
  { title: '绝句', author: '杜甫', text: '两个黄鹂鸣翠柳，一行白鹭上青天。窗含西岭千秋雪，门泊东吴万里船。', stage: 3 },
  // 第5阶段（三年级）
  { title: '所见', author: '袁枚', text: '牧童骑黄牛，歌声振林樾。意欲捕鸣蝉，忽然闭口立。', stage: 4 },
  { title: '山行', author: '杜牧', text: '远上寒山石径斜，白云生处有人家。停车坐爱枫林晚，霜叶红于二月花。', stage: 4 },
  { title: '望天门山', author: '李白', text: '天门中断楚江开，碧水东流至此回。两岸青山相对出，孤帆一片日边来。', stage: 4 },
  { title: '饮湖上初晴后雨', author: '苏轼', text: '水光潋滟晴方好，山色空蒙雨亦奇。欲把西湖比西子，淡妆浓抹总相宜。', stage: 4 },
  { title: '望洞庭', author: '刘禹锡', text: '湖光秋月两相和，潭面无风镜未磨。遥望洞庭山水翠，白银盘里一青螺。', stage: 4 },
  { title: '早发白帝城', author: '李白', text: '朝辞白帝彩云间，千里江陵一日还。两岸猿声啼不住，轻舟已过万重山。', stage: 4 },
];

/** 取古诗阶段数 */
export const POEM_STAGES = (() => {
  const stages = new Set(POEMS.map(p => p.stage));
  return [...stages].sort((a,b)=>a-b);
})();

/** 取某阶段起的古诗 keys（标题） */
export function poemKeysUpToStage(stageIdx) {
  return POEMS.filter(p => p.stage <= stageIdx).map(p => p.title);
}
