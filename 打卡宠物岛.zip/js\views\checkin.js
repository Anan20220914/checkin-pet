// views/checkin.js — 首页主界面 + 二级子页（学习/习惯/运动/家务）

import { getState } from '../store.js';
import {
  getTasksByCategory, toggleCheckTask, isTaskDone, getQuizResult, getTodayProgress,
  getStudyDoneCount, isDailyDuelDone,
} from '../tasks.js';
import { CATEGORIES, TASK_KIND, STUDY_MIN_FOR_DUEL } from '../db2.js';
import { esc } from '../utils.js';
import { switchTab } from '../app.js';
import { currentGiftPreview } from '../weekly.js';
import { openChineseQuiz } from './quiz-chinese.js';
import { openEnglishQuiz } from './quiz-english.js';
import { openMathQuiz } from './quiz-math.js';
import { openPoemQuiz } from './quiz-poem.js';
import { openBrainQuiz } from './quiz-brain.js';
import { openSpeakBattle } from './quiz-speak.js';
import { openIdiomQuiz } from './quiz-idiom.js';
import { openXiehouyuQuiz } from './quiz-xiehouyu.js';

const el = () => document.getElementById('view-checkin');

// 模块级子视图状态
let subView = 'home'; // 'home' | 'study' | 'habit' | 'sport' | 'life'

/** 切换 tab 时重置回主页（app.js switchTab 调用） */
export function resetSubView() { subView = 'home'; }

function setSubView(v) { subView = v; renderCheckin(); el().scrollTop = 0; }

export function renderCheckin() {
  if (subView === 'home') return renderHome();
  if (subView === 'study') return renderStudy();
  return renderCheckList(subView); // habit | sport | life
}

/* ============ 主界面 ============ */
function renderHome() {
  const s = getState();
  const prog = getTodayProgress();
  const pct = prog.total ? Math.round((prog.done / prog.total) * 100) : 0;
  const studyDone = getStudyDoneCount();
  const dueled = isDailyDuelDone();

  // 各分类完成数
  const groups = getTasksByCategory();
  const cnt = (cat) => {
    const list = groups[cat] || [];
    return list.filter(t => isTaskDone(t.id)).length;
  };

  let html = '';

  // 进度概览
  html += `
    <div class="card home-progress">
      <div class="progress-ring">
        <div class="ring" style="--pct:${pct}"><span>${prog.done}/${prog.total}</span></div>
        <div class="info">
          <div class="big">${prog.earned} 🪙</div>
          <div class="sub">今天已得积分 · 打卡进度 ${pct}%</div>
        </div>
      </div>
    </div>
  `;

  // 入口卡片网格
  const sportPts = groups.sport?.filter(t=>isTaskDone(t.id)).reduce((s,t)=>s+t.points,0) || 0;
  const lifePts = groups.life?.filter(t=>isTaskDone(t.id)).reduce((s,t)=>s+t.points,0) || 0;
  const habitPts = groups.habit?.filter(t=>isTaskDone(t.id)).reduce((s,t)=>s+t.points,0) || 0;
  html += `<div class="home-grid">`;
  const studyTasks = s.tasks.filter(t => t.category === 'study' && t.active);
  const studyTotal = studyTasks.length;
  html += homeTile('study', '📚', '学习打卡', `${studyDone}/${studyTotal} 完成`, studyDone >= studyTotal, 'study');
  html += homeTile('habit', '🌱', '习惯养成', cnt('habit')>0?`已得${habitPts}分`:'去打卡', cnt('habit')>0, 'habit');
  html += homeTile('sport', '⚽', '运动打卡', cnt('sport')>0?`已得${sportPts}分`:'去打卡', cnt('sport')>0, 'sport');
  html += homeTile('life', '🏠', '家务打卡', cnt('life')>0?`已得${lifePts}分`:'去打卡', cnt('life')>0, 'life');
  html += `</div>`;

  el().innerHTML = html;

  // 绑定入口
  el().querySelectorAll('.home-tile').forEach(t => t.onclick = () => setSubView(t.dataset.go));
}

function homeTile(go, icon, name, sub, done, theme = '') {
  return `<div class="home-tile ${done ? 'done' : ''} tile-${theme}" data-go="${go}">
    <div class="tile-icon">${icon}</div>
    <div class="tile-name">${name}</div>
    <div class="tile-sub">${sub}</div>
    ${done ? '<div class="tile-check">✓</div>' : ''}
  </div>`;
}

/* ============ 学习子页 ============ */
function renderStudy() {
  const s = getState();
  const tasks = s.tasks.filter(t => t.category === 'study' && t.active);
  let html = subHeader('学习打卡', '📚');

  html += `<div class="study-grid">`;
  for (const t of tasks) {
    const result = getQuizResult(t.id);
    const passed = result && result.done;
    const isBattle = t.kind === TASK_KIND.BATTLE;
    let sub;
    if (isBattle) sub = passed ? '✓ 打败读音小怪' : '读词攻击小怪';
    else if (t.quizType === 'idiom') sub = passed ? `✓ 已学会` : `每日1个 · 看完即过`;
    else if (t.quizType === 'xiehouyu') sub = passed ? `✓ 已记住` : `每日1句 · 看完即过`;
    else sub = passed ? `✓ ${result.correct}/${result.total} 通过` : `每日${t.dailyCount}题 · 80%通过`;
    html += `
      <div class="study-tile ${passed ? 'done' : ''} ${isBattle ? 'battle' : ''}" data-task="${t.id}">
        <div class="tile-icon">${isBattle ? '🗣️' : t.icon}</div>
        <div class="tile-name">${esc(t.title)}</div>
        <div class="tile-sub">${sub}</div>
        ${passed ? '<div class="tile-check">✓</div>' : ''}
      </div>
    `;
  }
  html += `</div>`;

  el().innerHTML = html;
  el().querySelector('#subBack').onclick = () => setSubView('home');
  el().querySelectorAll('.study-tile').forEach(node => {
    node.onclick = () => {
      const t = getState().tasks.find(x => x.id === node.dataset.task);
      if (!t) return;
      if (t.quizType === 'chinese') openChineseQuiz(t.id);
      else if (t.quizType === 'english') openEnglishQuiz(t.id);
      else if (t.quizType === 'math') openMathQuiz(t.id);
      else if (t.quizType === 'poem') openPoemQuiz(t.id);
      else if (t.quizType === 'brain') openBrainQuiz(t.id);
      else if (t.quizType === 'speak') openSpeakBattle(t.id);
      else if (t.quizType === 'idiom') openIdiomQuiz(t.id);
      else if (t.quizType === 'xiehouyu') openXiehouyuQuiz(t.id);
    };
  });
}

/* ============ 习惯/运动/家务勾选子页 ============ */
function renderCheckList(cat) {
  const meta = CATEGORIES[cat];
  const groups = getTasksByCategory();
  const list = groups[cat] || [];
  let html = subHeader(meta.name, meta.emoji);

  const done = list.filter(t => isTaskDone(t.id)).length;
  const earnedPts = list.filter(t=>isTaskDone(t.id)).reduce((s,t)=>s+t.points,0);
  html += `<div class="sub-summary">已勾选 ${done} 项 · 已得 ${earnedPts} 分（做一项得一项，不做没关系）</div>`;

  html += `<div class="card" style="padding:8px 12px">`;
  for (const t of list) {
    const isDone = isTaskDone(t.id);
    html += `
      <div class="task ${isDone ? 'done' : ''}" data-check="${t.id}">
        <div class="t-icon">${t.icon || '⭐'}</div>
        <div class="t-body">
          <div class="t-title">${esc(t.title)}</div>
          <div class="t-pts">+${t.points} 积分</div>
        </div>
        <div class="t-check">${isDone ? '✓' : ''}</div>
      </div>
    `;
  }
  html += `</div>`;

  el().innerHTML = html;
  el().querySelector('#subBack').onclick = () => setSubView('home');
  el().querySelectorAll('[data-check]').forEach(node => {
    node.onclick = () => toggleCheckTask(node.dataset.check);
  });
}

/* ============ 子页返回栏 ============ */
function subHeader(title, emoji) {
  return `
    <div class="sub-header">
      <button class="sub-back" id="subBack">‹</button>
      <span class="sub-emoji">${emoji}</span>
      <span class="sub-title">${esc(title)}</span>
    </div>
  `;
}

// 切到首页 tab 时重置子页到主界面（点底部"今日打卡"总回主页）
window.addEventListener('tab-switch', (e) => {
  if (e.detail.tab === 'checkin') {
    if (subView !== 'home') { subView = 'home'; renderCheckin(); }
  }
});
